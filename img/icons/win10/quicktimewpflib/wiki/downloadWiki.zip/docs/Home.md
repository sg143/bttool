**Project Description**
Library for use Quick Time in WPF Applications

When I'm created project in .NET 4.0 and tried to reference "Apple QuickTime Control 2.0" I'v got an error. But against 3.5 SP1 Runtime it is added normal. But 3.5 SP1 doesn't support embedded interop types. I've created this project to help people, if they want to use QuickTime in WPF Applications